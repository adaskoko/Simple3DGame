Hello and thank you for purchasing Cartoon Temple Building Kit package.

There is 429 fbx files all made to two prefabs. 

	Models:
Blocks42  fbx
Blocks And Bricks40  fbx
Decorative					54  fbx
Doors Gates Hallways		10  fbx
Ground +					54  fbx
Ground x					72  fbx
Ground Path					10  fbx	
Ground Stones Tile			13  fbx
Platforms Stairs Fences		41  fbx
Round						25  fbx
Sig Sag						20  fbx
Single Cubes				16  fbx
Square Holes				16  fbx
Wall						16  fbx

Total					429 fbx


Lightmaps are generated on import. No colliders are placed or generated.

On the models when lightmaps are baked you might see some dark leak on the edges.
You can ease this by enlarging the objects scale on the lightmap.
On the example scenes the lighting method is mostly set to baked (except scene 8 and 10).
So all the gameobjects are set to static and lights are set to bake.

Prefabs are set to all static.

One material and atlas texture for all models 2048*2048 png.
The emission texture is only white for the Arrow, Cross, Light Orb and Sun Symbol models.
If you are using the emission texture you can change the white square to desired color inside
any texturing program like photoshop.
More emission models might come in future if updated. Depending on download rates.

For questions you can contact me at:
a.kolmonen@gmail.com